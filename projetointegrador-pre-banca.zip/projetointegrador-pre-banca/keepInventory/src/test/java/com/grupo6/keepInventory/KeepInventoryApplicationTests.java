package com.grupo6.keepInventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeepInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
