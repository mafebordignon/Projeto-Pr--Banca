const nome =  document.getElementById("field-nome");
const sobrenome =  document.getElementById("field-sobrenome");
const email = document.getElementById("field-email");
const numeroDeCadastro = document.getElementById("field-numero-cadastro");
const senha = document.getElementById("field-senha");
const confirmarSenha = document.getElementById("field-confirmar-senha");
const botao = document.getElementById("submit-button")
const form = document.getElementById("form")
var id;
var usuario;
window.onload = function() {
    let url = window.location.href;
    let parts = url.split('/');
    id = parts[parts.length - 1];
    console.log(id)
    fetch('/usuarios/'+id)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar usuário');
            }
            return response.json();
        })
        .then(data => {
            usuario = data;
            nome.value = usuario.nome
            sobrenome.value = usuario.sobrenome
            email.value = usuario.email
            numeroDeCadastro.value = usuario.numeroDeCadastro

        })
        .catch(error => {
            console.error('Erro:', error);
        });
};

function verificar(event){
    event.preventDefault()
    if (nome.value != usuario.nome || sobrenome.value != usuario.sobrenome || email.value != usuario.email || numeroDeCadastro.value != usuario.numeroDeCadastro || senha.value != '' || confirmarSenha.value != ''){
        if (senha.value !== '' || confirmarSenha.value !== ''){
            var alertFormatoSenha = "A senha deve corresponder aos seguintes requisitos:\n - Deve conter pelo menos 8 caracteres.\n - Deve conter pelo menos 1 número.\n - Deve conter pelo menos 1 símbolo especial.";
            var regexNumero = /[0-9]/;
            var regexSimbolo = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
            if (!regexSimbolo.test(senha.value) || !regexNumero.test(senha.value) || senha.value.length < 8) {
                alert(alertFormatoSenha);
                return false;
            }
            if (senha.value.indexOf(' ') !== -1) {
                alert("A senha não pode conter espaços.");
                return false;
            }
            if (senha.value !== confirmarSenha.value){
                alert("Campo de senha e confirmação de senha devem ser o mesmo!");
                return;
            }
        }

        atualizar();
    } else {
        alert("Nenhum campo foi alterado!");
    }
}

function atualizar(){
    const usuarioAtualizado = {
        nome: nome.value,
        sobrenome: sobrenome.value,
        email: email.value, // Atualizando o campo de e-mail
        senha: senha.value,
        numeroDeCadastro: numeroDeCadastro.value
    };
    fetch('/usuarios/'+id, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(usuarioAtualizado)
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(errorMsg => {
                    throw new Error(errorMsg);
                });
            }
            return response.json();
        })
        .then(data => {
            if (data && data.error && data.error.includes('O email já está associado a outra conta')) {
                    alert('O email já está associado a outra conta');
            } else {
                alert('Usuário atualizado com sucesso!');
            }
        })
        .catch(error => {
            alert(error);
        });
}

form.addEventListener('submit', verificar)