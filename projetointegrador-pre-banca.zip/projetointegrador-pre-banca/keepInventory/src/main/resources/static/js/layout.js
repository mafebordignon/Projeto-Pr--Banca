function toggleNav() {
    var nav = document.getElementById('side-nav');

    if (nav) {
        if (!nav.style.left || nav.style.left === '-10vw') {
            nav.style.left = '0vw';
        } else {
            nav.style.left = '-10vw';
        }
    }
}

function closeNavOnClickOutside(event) {
    var nav = document.getElementById('side-nav');
    var headerNavButton = document.getElementById('header-nav-button');

    if (!nav.contains(event.target) && !headerNavButton.contains(event.target)) {
        nav.style.left = '-10vw';
    }
}

document.body.addEventListener('click', closeNavOnClickOutside);