//fetch('/categorias')
//   .then(response => {
//        if (!response.ok) {
//                       throw new Error('Erro ao buscar as opções.');
//        }
//        return response.json();
//   })
//    .then(options => {
//       var flagUtensilio = 1;
//        var select = document.getElementById('idCategoria');
//        select.innerHTML = ''; // Limpa as opções existentes
//        options.forEach(option => {
//            if (option.nome === document.getElementById('idCategoria').innerText) {
//                flagUtensilio = option.id
//                }
//            var optionElement = document.createElement('option');
//            optionElement.value = option.id;
//            optionElement.textContent = option.nome;
//            select.appendChild(optionElement);
//            });
//              select.value =  flagUtensilio;
//
//        select.style.display = 'block'; // Exibe o select
//    })
//   .catch(error => {
//        console.error('Erro:', error);
//    });

fetch('/estados')
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao buscar as opções.');
        }
        return response.json();
    })
    .then(options => {
        var flagStatus = 1;
        var select = document.getElementById('idEstado');
        select.innerHTML = ''; // Limpa as opções existentes
        options.forEach(option => {
            if (option.nome === document.getElementById('idEstado').innerText) {
                flagStatus = option.id
            }
            var optionElement = document.createElement('option');
            optionElement.value = option.id;
            optionElement.textContent = option.nome;
            select.appendChild(optionElement);
        });
        select.value =  flagStatus;

        select.style.display = 'block'; // Exibe o select
    })
    .catch(error => {
        console.error('Erro:', error);
    });

fetch('/localizacoes')
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao buscar as opções.');
        }
        return response.json();
    })
    .then(options => {
        var flagOrigem = 1; //
        var select = document.getElementById('idLocalizacao');
        select.innerHTML = ''; // Limpa as opções existentes
        options.forEach(option => {
            if (option.nome === document.getElementById('idLocalizacao').innerText){ //
                flagOrigem = option.id; //
            } //
            var optionElement = document.createElement('option');
            optionElement.value = option.id;
            optionElement.textContent = option.nome;
            select.appendChild(optionElement);
        });
        select.value = flagOrigem; //

        select.style.display = 'block'; // Exibe o select
    })
    .catch(error => {
        console.error('Erro:', error);
    });

const localizacao = document.getElementById("localizacao")
const marca = document.getElementById("marca")
const potencia = document.getElementById("potencia")
const descricao = document.getElementById("descricao")
//const localizacao = document.getElementById("localizacao")
const modelo = document.getElementById("modelo")
const numeroNotaFiscal = document.getElementById("numeroNotaFiscal")
const disponibilidade = document.getElementById("disponibilidade")
const dataEntrada = document.getElementById("dataEntrada")
const categoria = document.getElementById("categoria")
const numeroSerie = document.getElementById("numeroSerie")


function salvarItem() {
    item = {
        descricao: descricao.value,
        numeroNotaFiscal: numeroNotaFiscal.value,
        marca: marca.value,
        modelo: modelo.value,
        numeroSerie: numeroSerie.value,
        potencia: potencia.value,
        dataEntrada: (dataEntrada.value)+ "T00:00:00",
            categoria:
            {
                id: idCategoria
            },
        estado: {
            id: idEstado
        },
        disponibilidade: {
            id: disponibilidade_id
        },
        localizacao: {
            id: idLocalizacao
        }
    };

    console.log(JSON.stringify(item));
    path = '/itens'
        fetch(path, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro ao cadastrar item');
                }
                return response.json();
            })
            .then(data => {
                console.log('Item cadastrado com sucesso:', data);
            })
            .catch(error => {
                console.error('Erro:', error);
            });
}
