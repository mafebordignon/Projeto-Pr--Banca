const select = document.getElementById("tables")
const list = document.getElementById("registrations")
const form = document.getElementById("form")
const nomeField = document.getElementById("nome")
const prev = document.getElementById("prev")
const next = document.getElementById("next")
const pageNumber = document.getElementById("page")

function fetchGetCampo(url){
    fetch(url)
            .then(response => response.json())
            .then(data => {
                pageNumber.max = (data.totalPages -1)

                data.content.forEach(campo => {
                    item = document.createElement("div")

                    id = document.createElement("p")
                    id.textContent = campo.id

                    nome = document.createElement("p")
                    nome.textContent = campo.nome

                    buttonDelete = document.createElement("button")
                    buttonDelete.setAttribute("id", campo.id);
                    buttonDelete.textContent = "excluir"
                    buttonDelete.addEventListener("click", () => excluirCampo(campo.id));

                    item.appendChild(id)
                    item.appendChild(nome)
                    item.appendChild(buttonDelete)

                    list.appendChild(item)
                });
            });
}

function carregarCampos(){
    page = pageNumber.value
    console.log('/categorias/'+page)
    while (list.firstChild) {
            list.removeChild(list.firstChild);
    }
    if(select.value==="categorias"){
        fetchGetCampo('/categorias/'+page);
        console.log('/categorias/'+page)
    }
    if(select.value==="tiposacao"){
        fetchGetCampo('/tiposacao/'+page);
    }
    if(select.value==="disponibilidades"){
        fetchGetCampo('/disponibilidades/'+page);
    }
    if(select.value==="estados"){
        fetchGetCampo('/estados/'+page);
    }
}

function fetchDeleteCampo(url,id){
    fetch(url, {
      method: 'DELETE',
    })
    .then(response => {
        if (response.ok) {
            alert(`Campo com ID ${id} excluído com sucesso!`)
            console.log(`Campo com ID ${id} excluído com sucesso!`);
        } else {
            alert('Erro ao excluir campo')
            console.error('Erro ao excluir campo:', response.status);
        }
        carregarCampos()
    })
    .catch(error => {
            alert('Erro ao excluir campo')
            console.error('Erro ao excluir campo:', error);
        });
}

function excluirCampo(id){
    if(select.value==="categorias"){
        fetchDeleteCampo('/categorias'+'/'+id,id);
    }
    if(select.value==="tiposacao"){
        fetchDeleteCampo('/tiposacao'+'/'+id,id);
    }
    if(select.value==="disponibilidades"){
        fetchDeleteCampo('/disponibilidades'+'/'+id,id);
    }
    if(select.value==="estados"){
        fetchDeleteCampo('/estados'+'/'+id,id);
    }
}

function cadastrarCampo(event){
  event.preventDefault();
      if(select.value != "default"){
          nome = nomeField.value

          path = '/' + select.value
          fetch(path, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({nome})
          })
            .then(response => {
              if (!response.ok) {
                return response.text().then(errorMsg => {
                  throw new Error(errorMsg);
                });
              }
              return response.json();
            })
            .then(data => {
              alert(select.value+" cadastrado com sucesso!");
              pageNumber.value = 0;
              carregarCampos()
            })
            .catch(error => {
              alert('Erro: '+ error.message);
            });



      } else {
          alert("Selecione um dos Campos para cadastrar algo!")
      }
}

//
//function cadastrarCampo(event){
//    event.preventDefault();
//    if(select.value != "default"){
//        nome = nomeField.value
//
//        if (nome !== ''){
//            path = '/' + select.value
//                    fetch(path, {
//                        method: 'POST',
//                        headers: {
//                            'Content-Type': 'application/json'
//                        },
//                        body: JSON.stringify({nome})
//                    })
//                    .then(() => {
//                        alert(select.value+" cadastrado com sucesso!");
//                        pageNumber.value = 0;
//                        carregarCampos()
//                    })
//        } else {
//            alert("Campo vazio!")
//        }
//
//    } else {
//        alert("Selecione um dos Campos para cadastrar algo!")
//    }
//}

form.onsubmit = cadastrarCampo;
select.onchange = () => {pageNumber.value = 0; carregarCampos()} ;
pageNumber.onchange = carregarCampos;
next.onclick = () => {
    if(pageNumber.value < pageNumber.max){
        pageNumber.value = parseInt(pageNumber.value + 1)
    }
    pageNumber.dispatchEvent(new Event('change'));
}
prev.onclick = () => {
     if(pageNumber.value > pageNumber.min){
          pageNumber.value = pageNumber.value-1
     }
     pageNumber.dispatchEvent(new Event('change'));
}