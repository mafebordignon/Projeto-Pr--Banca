var id;
 // window.onload=function (Puxa as informações do item)
const campoCod = document.getElementById("cod")
const campoItem = document.getElementById("item")
const campoMarca = document.getElementById("marca")
const campoModelo = document.getElementById("modelo")
const camponumeroSerie = document.getElementById("num_de_serie")
const campoCategoria = document.getElementById("categoria")
const campoOrigem = document.getElementById("origem")
const campoPotencia = document.getElementById("potencia")
const campoNumeroNotaFiscal = document.getElementById("nota_fiscal")
const campoDataEntrada = document.getElementById("data_nota_fiscal")
const campoDisponibilidade = document.getElementById("disponibilidade")
const campoEstado = document.getElementById("status")

// buttonSalvar.addEventListener (Puxa as informações a serem salvadas)
const buttonSalvar = document.getElementById("salvar")
const campoLocalAtual = document.getElementById("loc_atual")
const campoResponsavel = document.getElementById("responsavel")
const campoDescricao = document.getElementById("descricao")

const url = window.location.href;
const parts = url.split('/');
Id = parts[parts.length - 1];

var itemCarregado;
// Mostra as infromações puxadas do item
window.onload=function (){
    fetch('/itens/'+Id)
        .then(response => {
            if(!response.ok){
                throw new Error('Erro ao buscar item');
            }
            return response.json();
        })

        .then(data => {
            campoCod.value = data.id;
            campoItem.value = data.descricao;
            campoMarca.value = data.marca;
            campoModelo.value = data.modelo;
            camponumeroSerie.value = data.numeroSerie;
            campoCategoria.value = data.categoria.nome;
            campoOrigem.value = data.localizacao.nome;
            campoPotencia.value = data.potencia;
            campoNumeroNotaFiscal.value = data.numeroNotaFiscal;
            campoDisponibilidade.value = data.disponibilidade.nome;
            console.log(data.disponibilidade.nome);
            campoEstado.value = data.estado.nome;
            // console.log(data.dataEntrada);
            // campoDataEntrada.value = data.dataEntrada;

            itemCarregado = data;
        })

        .catch(error => {
            console.error('Erro:', error)
        })

    fetch('/localizacoes')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar as opções.');
            }
            return response.json();
        })
        .then(options => {
            var flagOrigem = 1;
            var select = document.getElementById('loc_atual');
            select.innerHTML = ''; // Limpa as opções existentes
            options.forEach(option => {
                if (option.nome === document.getElementById('origem').innerText){ //
                    flagOrigem = option.id;
                }
                var optionElement = document.createElement('option');
                optionElement.value = option.id;
                optionElement.textContent = option.nome;
                select.appendChild(optionElement);
            });
            select.value = flagOrigem;
        })
        .catch(error => {
            console.error('Erro:', error);
        });

}

// Salva as informações colocadas
buttonSalvar.addEventListener("click", function() {
    async function adicionarAcao() {

        const acao = {
            item: { id: Id },
            tipoacao: { id: 1},
            localizacao: { id: campoLocalAtual.value },
            usuario: { id: 1 },
            dataEmprestimo: getFormattedDate(),
            dataDevolucao: getFormattedDate(),
            descricao: campoDescricao.value,
            entidade: campoResponsavel.value,
        };

        try {
            const response = await fetch('/acoes', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(acao)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Erro ao adicionar ação');
            }

            const novaAcao = await response.json();
            console.log('Ação adicionada com sucesso:', novaAcao);

            salvarItem();


            window.location.href = '/especificacao-item/'+Id;
        } catch (error) {
            console.error('Erro:', error.message);
        }
    }

    adicionarAcao();
});


function getFormattedDate() {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}T00:00:00`;
}



function salvarItem(){
    itemCarregado.disponibilidade.id = 2;
    itemCarregado.disponibilidade.nome = "Emprestado"
    console.log(itemCarregado)
    fetch("/itens/"+Id, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(itemCarregado)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Erro ao atualizar o item');
      }
      console.log('Item atualizado com sucesso!');
    })
    .catch(error => {
      console.error('Erro:', error);
    });
}