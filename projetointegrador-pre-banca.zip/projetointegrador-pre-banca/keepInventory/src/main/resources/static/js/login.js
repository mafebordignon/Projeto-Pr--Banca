document.getElementById("login-form").addEventListener("submit", function(event) {
            event.preventDefault();

            carregarUsuarios();
});

function carregarUsuarios() {
    var email = document.getElementById("field-email").value;
    var senha = document.getElementById("field-senha").value;
    var nome = "";
    var sobrenome = "";
    var numeroDeCadastro = "";
    var usuarioData = {
        email: email,
        senha: senha,
        nome: nome,
        sobrenome: sobrenome,
        numeroDeCadastro: numeroDeCadastro
    };
    fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(usuarioData)
    })
    .then(response => {
      if (response.ok) {
        response.json()
        .then(data => {
            console.log('Dados retornados:', data);

            localStorage.setItem('usuarioId', data.id);


            window.location.href = "/inventario";
        })
        .catch(error => {
            console.error('Erro ao converter resposta para JSON:', error);
        });
      } else {
        alert('Credenciais inválidas');
      }
    })
    .catch(error => {
      console.error('Erro ao fazer login:', error);
    });
}
