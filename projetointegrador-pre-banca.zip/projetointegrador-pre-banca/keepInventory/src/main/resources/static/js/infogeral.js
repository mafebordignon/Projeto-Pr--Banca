
document.addEventListener('DOMContentLoaded', () => {

    var itemCarregado;
    const prev = document.getElementById("prev");
    const next = document.getElementById("next");
    const pageNumber = document.getElementById("page");
    const pageSize = 10;
    let currentPage = 0;
    let maxPage = 0;
    let filter = '';
    let idFilter = '';
    let url = '';
    let selectedCategory = '';

    function changeUrl() {
        url = `/itens?pageNumber=${currentPage}&pageSize=${pageSize}&filter=${filter}&idFilter=${idFilter}`;
    }

    function changeCategoryUrl(categoriaId) {
        if (selectedCategory === categoriaId) {
            // Se a categoria selecionada for clicada novamente, resetar filtro
            filter = 'none';
            idFilter = '1';
            selectedCategory = '';
        } else {
            // Alterar para nova categoria
            filter = 'categoria';
            idFilter = categoriaId;
            selectedCategory = categoriaId;
        }
        currentPage = 0;
        changeUrl();
    }

    function carregarItens() {
        fetch(url)
            .then(response => response.json())
            .then(data => {
                exibirItens(data);
                console.log(data);
                maxPage = data.totalPages - 1;
            })
            .catch(error => {
                console.error('Erro:', error);
            });
    }

//<div class='category-header1'>
//                            <button class='category-title1' data-category="1">Categoria 1</button>
//                        </div>
//                        <div class='category-header2'>
//                            <button class='category-title2' data-category="2">Categoria 2</button>
//                        </div>
//                        <div class='category-header3'>
//                            <button class='category-title3'>Categoria +</button>
//                        </div>
    function carregarCategorias(){
        fetch("/categorias")
            .then(response => response.json())
            .then(data => {
                console.log(data);
                data.forEach(categoria => {
                    const boxcat = document.getElementsByClassName('box-cat')[0];
                    const categoryHeader = document.createElement('div');
                    categoryHeader.classList.add('category-header1');

                    const buttonCat = document.createElement('button');
                    buttonCat.classList.add('category-title1');
                    buttonCat.setAttribute('data-category', categoria.id);
                    buttonCat.textContent = categoria.nome;

                    categoryHeader.appendChild(buttonCat);

                    boxcat.appendChild(categoryHeader);

                    const categoryButtons = document.querySelectorAll('.box-cat button');
                    categoryButtons.forEach(button => {
                        button.onclick = () => {
                            const categoriaId = button.getAttribute('data-category');
                            console.log(categoriaId)
                            changeCategoryUrl(categoriaId);
                            pageNumber.value = 0;
                            carregarItens();
                        };
                    });


                });
            })
            .catch(error => {
                console.error('Erro:', error);
            });


    }
    async function getLocalAtual(itemId) {
        try {
            const response = await fetch(`/acoes/${itemId}`);
            if (!response.ok) {
                throw new Error('Erro ao buscar dados do servidor');
            }
            const data = await response.json();
            if ((data.content).length === 0) {
                return itemCarregado.localizacao.nome;
            } else {
                return data.content[0].localizacao.nome;
            }
        } catch (error) {
            console.error('Erro:', error);
            return 'Erro ao buscar localização';
        }
    }
    async function exibirItens(data) {
        const container = document.getElementById('container');
        container.innerHTML = '';

        for (const item of data.content) {
            itemCarregado = item;
            const localAtual = await getLocalAtual(item.id);

            const itemElement = document.createElement('div');
            itemElement.setAttribute('class', 'grid-layout-item');
            const htmlContent = `
                <a href="/especificacao-item/${item.id}" class="ptamanho idlayout">#${item.id}</a>
                <div class="ptamanho itemlayout">${item.descricao}</div>
                <div class="ptamanho locallayout">${localAtual}</div>
                <div class="ptamanho origemlayout">${item.localizacao.nome}</div>
                <div class="ptamanho marcalayout">${item.marca}</div>
                <div class="ptamanho ativolayout">${item.estado.nome}</div>
                <div class="ptamanho Disponivel">${item.disponibilidade.nome}</div>
            `;
            itemElement.innerHTML = htmlContent;
            container.appendChild(itemElement);
        }
    }

    next.onclick = () => {
        if (parseInt(pageNumber.value) < maxPage) {
            currentPage = parseInt(pageNumber.value) + 1;
            pageNumber.value = currentPage;
            changeUrl();
            carregarItens();
        }
    };

    prev.onclick = () => {
        if (parseInt(pageNumber.value) > 0) {
            currentPage = parseInt(pageNumber.value) - 1;
            pageNumber.value = currentPage;
            changeUrl();
            carregarItens();
        }
    };

    window.onload = function () {
        pageNumber.value = 0;
        changeUrl();
        carregarItens();
        carregarCategorias();
    };
});


