
function validateForm(event) {
    event.preventDefault();
    var nome =  document.getElementById("field-nome").value;
    var sobrenome =  document.getElementById("field-sobrenome").value;
    var email = document.getElementById("field-email").value;
    var numeroDeCadastro = document.getElementById("field-numero-cadastro").value;
    var senha = document.getElementById("field-senha").value;
    var confirmarSenha = document.getElementById("field-confirmar-senha").value;

    var alertFormatoSenha = "A senha deve corresponder aos seguintes requisitos:\n - Deve conter pelo menos 8 caracteres.\n - Deve conter pelo menos 1 número.\n - Deve conter pelo menos 1 símbolo especial.";

    if (senha.length < 8) {
        alert(alertFormatoSenha);
        return false;
    }

    var regexNumero = /[0-9]/;
    if (!regexNumero.test(senha)) {
        alert(alertFormatoSenha);
        return false;
    }

    var regexSimbolo = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
    if (!regexSimbolo.test(senha)) {
        alert(alertFormatoSenha);
        return false;
    }

    if (senha.indexOf(' ') !== -1) {
        alert("A senha não pode conter espaços.");
        return false;
    }

    if (senha !== confirmarSenha) {
      alert("As senhas não coincidem.");
      return false;  
    } else {
        fetch('/usuarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nome, sobrenome, email, numeroDeCadastro, senha })
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(errorMsg => {
                    throw new Error(errorMsg);
                });
            }
            return response.json();
        })

        .then(() => {
            alert("Usuário cadastrado com sucesso!");
            window.location.href = "/login";
        })
        .catch(error => {
            alert('Erro: ' + error.message);
        });
        return true;
    }

}



document.getElementById('logon-form').addEventListener('submit', validateForm);