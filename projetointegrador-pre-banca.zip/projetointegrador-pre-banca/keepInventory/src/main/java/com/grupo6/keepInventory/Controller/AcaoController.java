package com.grupo6.keepInventory.Controller;

import com.grupo6.keepInventory.Model.*;
import com.grupo6.keepInventory.Repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/acoes")
public class AcaoController {
    private final AcaoRepository acaoRepository;
    private final TipoacaoRepository tipoAcaoRepository;
    private final LocalizacaoRepository localizacaoRepository;
    private final ItemRepository itemRepository;
//    private final AnexoRepository anexoRepository;
    private final UsuarioRepository usuarioRepository;
    @Autowired
    public AcaoController(AcaoRepository acaoRepository,
                         TipoacaoRepository tipoAcaoRepository,
                         LocalizacaoRepository localizacaoRepository,
                         ItemRepository itemRepository,
//                         AnexoRepository anexoRepository,
                         UsuarioRepository usuarioRepository) {
        this.acaoRepository = acaoRepository;
        this.tipoAcaoRepository = tipoAcaoRepository;
        this.localizacaoRepository = localizacaoRepository;
        this.itemRepository = itemRepository;
//        this.anexoRepository = anexoRepository;
        this.usuarioRepository = usuarioRepository;
    }
    @GetMapping
    public List<Acao> acoes() {
        return acaoRepository.findAll();
    }
    @GetMapping("/{itemid}")
    public ResponseEntity<Page<Acao>> getByItem(@RequestParam(defaultValue = "0") int pageNumber, @RequestParam(defaultValue = "10") int pageSize, @PathVariable Long itemid){
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<Acao> listaAcoes = acaoRepository.findByItem(itemid, pageable);
        return ResponseEntity.ok(listaAcoes);
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @PostMapping
    public Acao adicionar(@RequestBody Acao acao) {
        Tipoacao tipoAcao = tipoAcaoRepository.findById(acao.getTipoacao().getId())
                .orElseThrow(() -> new RuntimeException("Tipoacao não encontrado"));
        acao.setTipoacao(tipoAcao);

        Localizacao localizacao = localizacaoRepository.findById(acao.getLocalizacao().getId())
                .orElseThrow(() -> new RuntimeException("Localizacao não encontrada"));
        acao.setLocalizacao(localizacao);

        Item item = itemRepository.findById(acao.getItem().getId())
                .orElseThrow(() -> new RuntimeException("Item não encontrado"));
        acao.setItem(item);

//        Anexo anexo = anexoRepository.findById(acao.getAnexo().getId())
//                .orElseThrow(() -> new RuntimeException("Anexo não encontrado"));
//        acao.setAnexo(anexo);

        Usuario usuario = usuarioRepository.findById(acao.getUsuario().getId())
                .orElseThrow(() -> new RuntimeException("Usuario não encontrado"));
        acao.setUsuario(usuario);

        return acaoRepository.save(acao);
    }

    @PutMapping("/{id}")
    public Acao atualizarAcao(@PathVariable Long id, @RequestBody Acao acaoAtualizado) {
        return acaoRepository.findById(id)
                .map(acao -> {
                    acao.setDescricao(acaoAtualizado.getDescricao());
                    acao.setId(acaoAtualizado.getId());
                    acao.setDataEmprestimo(acaoAtualizado.getDataEmprestimo());
                    acao.setDataDevolucao(acaoAtualizado.getDataDevolucao());
                    acao.setEntidade(acaoAtualizado.getEntidade());


                    Tipoacao tipoAcao = tipoAcaoRepository.findById(acaoAtualizado.getTipoacao().getId())
                            .orElseThrow(() -> new RuntimeException("Tipoacao não encontrado"));
                    acao.setTipoacao(tipoAcao);

                    Localizacao localizacao = localizacaoRepository.findById(acaoAtualizado.getLocalizacao().getId())
                            .orElseThrow(() -> new RuntimeException("Localizacao não encontrada"));
                    acao.setLocalizacao(localizacao);

                    Item item = itemRepository.findById(acaoAtualizado.getItem().getId())
                            .orElseThrow(() -> new RuntimeException("Item não encontrado"));
                    acao.setItem(item);

//                    Anexo anexo = anexoRepository.findById(acaoAtualizado.getAnexo().getId())
//                            .orElseThrow(() -> new RuntimeException("Anexo não encontrado"));
//                    acao.setAnexo(anexo);

                    Usuario usuario = usuarioRepository.findById(acaoAtualizado.getUsuario().getId())
                            .orElseThrow(() -> new RuntimeException("Usuario não encontrado"));
                    acao.setUsuario(usuario);

                    return acaoRepository.save(acao);
                })
                .orElseThrow(() -> new RuntimeException("Acao não encontrada com o id: " + id));
    }

    @DeleteMapping("/{id}")
    public void deletarAcao(@PathVariable Long id) {
        acaoRepository.deleteById(id);
    }
}
