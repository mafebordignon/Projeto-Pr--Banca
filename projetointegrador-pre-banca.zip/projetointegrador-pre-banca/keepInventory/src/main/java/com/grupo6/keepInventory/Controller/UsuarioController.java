package com.grupo6.keepInventory.Controller;

import java.util.List;

import com.grupo6.keepInventory.Model.Disponibilidade;
import com.grupo6.keepInventory.Model.Usuario;
import com.grupo6.keepInventory.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private final PasswordEncoder passwordEncoder;
    private final UsuarioRepository usuarioRepository;
    @Autowired
    public UsuarioController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }
    @GetMapping
    public List<Usuario>listar() {
        return usuarioRepository.findAll();
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @PostMapping
    public ResponseEntity<?> adicionar(@RequestBody Usuario usuario) {
        try {
            for (Usuario u : usuarioRepository.findAll()) {
                if (usuario.getEmail().equals(u.getEmail())) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("O email já está associado a outra conta");
                }
            }
            usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
            Usuario novoUsuario = usuarioRepository.save(usuario);
            return ResponseEntity.ok(novoUsuario);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request");
        }
    }
    @PutMapping("/{id}")
    public Usuario atualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuarioAtualizado) {
        return usuarioRepository.findById(id)
                .map(usuario -> {
                    usuario.setNome(usuarioAtualizado.getNome());
                    usuario.setSobrenome(usuarioAtualizado.getSobrenome());
                    usuario.setEmail(usuarioAtualizado.getEmail());
                    usuario.setSenha(usuarioAtualizado.getSenha());
                    usuario.setNumeroDeCadastro(usuarioAtualizado.getNumeroDeCadastro());
                    return usuarioRepository.save(usuario);
                })
                .orElseThrow();
    }

    @DeleteMapping("/{id}")
    public void deletarUsuario(@PathVariable Long id) {
        usuarioRepository.deleteById(id);
    }
}

