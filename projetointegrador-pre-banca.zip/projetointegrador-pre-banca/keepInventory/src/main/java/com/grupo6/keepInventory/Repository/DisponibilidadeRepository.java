package com.grupo6.keepInventory.Repository;
import com.grupo6.keepInventory.Model.Disponibilidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface DisponibilidadeRepository extends JpaRepository<Disponibilidade, Long> , PagingAndSortingRepository<Disponibilidade,Long> {
}
