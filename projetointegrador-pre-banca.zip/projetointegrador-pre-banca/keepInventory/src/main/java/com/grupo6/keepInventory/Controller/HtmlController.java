package com.grupo6.keepInventory.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HtmlController {

    @GetMapping("/")
    public String redirectToLogin() {
        return "redirect:/login";
    }
    @GetMapping("/login")
    public String login() {
        return "login";
    }
    @RequestMapping(value = "/logon", method = RequestMethod.GET)
    public String logon() {
        return "logon";
    }

    @GetMapping("/campos-ativos")
    public String campoAtivos() {
        return "campoativo";
    }

    @GetMapping("inventario")
    public String infoGeral() {
        return "infogeral";
    }
    @GetMapping("/especificacao-item/{id}")
    public String especificacaoItem(@PathVariable Long id, Model model) {
        return "especificacaoItem";
    }

    @GetMapping("/alterar-usuario/{id}")
    public String alterarUsuario(@PathVariable Long id, Model model) {
        return "alterarusuario";
    }

    @GetMapping("/devolucao/{id}")
    public String devolucao(@PathVariable long id, Model model) {
        return "devolucao";
    }

    @GetMapping("/emprestimo/{id}")
    public String emprestimo(@PathVariable long id, Model model) {
        return "emprestimo";
    }


    @GetMapping("/cadastro-item")
    public String registerItem() {
        return "register";
    }

}

