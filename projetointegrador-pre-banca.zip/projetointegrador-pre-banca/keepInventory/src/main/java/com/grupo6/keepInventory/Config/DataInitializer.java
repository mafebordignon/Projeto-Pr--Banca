package com.grupo6.keepInventory.Config;

import com.grupo6.keepInventory.Model.*;
import com.grupo6.keepInventory.Repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class DataInitializer {

    @Bean
    public CommandLineRunner initDatabase(
            CategoriaRepository categoriaRepository,
            DisponibilidadeRepository disponibilidadeRepository,
            EstadoRepository estadoRepository,
            LocalizacaoRepository localizacaoRepository,
            TipoacaoRepository tipoAcaoRepository,
            UsuarioRepository usuarioRepository,
            ItemRepository itemRepository,
            PasswordEncoder passwordEncoder) {

        return args -> {
            if (categoriaRepository.count() == 0) {
                Categoria utilitario = new Categoria("Utilitario");
                Categoria maquinario = new Categoria("Maquinario");
                categoriaRepository.saveAll(List.of(utilitario, maquinario));
            }

            if (disponibilidadeRepository.count() == 0) {
                Disponibilidade disponivel = new Disponibilidade("Disponivel");
                Disponibilidade emprestado = new Disponibilidade("Emprestado");
                disponibilidadeRepository.saveAll(List.of(disponivel, emprestado));
            }

            if (estadoRepository.count() == 0) {
                Estado ativo = new Estado("Ativo");
                Estado inativo = new Estado("Inativo");
                estadoRepository.saveAll(List.of(ativo, inativo));
            }

            if (localizacaoRepository.count() == 0) {
                List<Localizacao> localizacoes = List.of(
                        new Localizacao("Localizacao 1"),
                        new Localizacao("Localizacao 2"),
                        new Localizacao("Localizacao 3"),
                        new Localizacao("Localizacao 4"),
                        new Localizacao("Localizacao 5"),
                        new Localizacao("Localizacao 6")
                );
                localizacaoRepository.saveAll(localizacoes);
            }

            if (tipoAcaoRepository.count() == 0) {
                Tipoacao emprestimo = new Tipoacao("Emprestimo");
                Tipoacao devolucao = new Tipoacao("Devolução");
                tipoAcaoRepository.saveAll(List.of(emprestimo, devolucao));
            }

            if (usuarioRepository.count() == 0) {
                Usuario admin = new Usuario("Admin", "Admin", "Admin@Admin.com", "123456", passwordEncoder.encode("Admin"));
                usuarioRepository.save(admin);
            }

            if (itemRepository.count() == 0) {
                Categoria categoria = categoriaRepository.findAll().get(0);
                Estado estado = estadoRepository.findAll().get(0);
                Disponibilidade disponibilidade = disponibilidadeRepository.findAll().get(0);
                Localizacao localizacao = localizacaoRepository.findAll().get(0);

                Item item1 = new Item();
                item1.setDescricao("Item 1");
                item1.setNumeroNotaFiscal("123456");
                item1.setMarca("Marca 1");
                item1.setModelo("Modelo 1");
                item1.setNumeroSerie("123456789");
                item1.setPotencia(100);
                item1.setDataEntrada(LocalDateTime.now());
                item1.setCategoria(categoria);
                item1.setEstado(estado);
                item1.setDisponibilidade(disponibilidade);
                item1.setLocalizacao(localizacao);

                Item item2 = new Item();
                item2.setDescricao("Item 2");
                item2.setNumeroNotaFiscal("654321");
                item2.setMarca("Marca 2");
                item2.setModelo("Modelo 2");
                item2.setNumeroSerie("987654321");
                item2.setPotencia(200);
                item2.setDataEntrada(LocalDateTime.now());
                item2.setCategoria(categoria);
                item2.setEstado(estado);
                item2.setDisponibilidade(disponibilidade);
                item2.setLocalizacao(localizacao);

                itemRepository.saveAll(List.of(item1, item2));
            }
        };
    }
}