package com.grupo6.keepInventory.Repository;
import com.grupo6.keepInventory.Model.Anexo;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AnexoRepository extends JpaRepository<Anexo, Long>{
}
