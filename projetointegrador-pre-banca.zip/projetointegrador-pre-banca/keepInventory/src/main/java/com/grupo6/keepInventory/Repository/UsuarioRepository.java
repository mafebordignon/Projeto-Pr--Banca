package com.grupo6.keepInventory.Repository;

import com.grupo6.keepInventory.Model.Item;
import com.grupo6.keepInventory.Model.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long>, PagingAndSortingRepository<Usuario,Long> {
    @Query(value = "SELECT * FROM usuario WHERE email = ?1", nativeQuery = true)
    Optional<Usuario> findByEmail(String Email);
}
